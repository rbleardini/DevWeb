from django.shortcuts import render

# Create your views here.
def saude(request):
    return render(request,"saude.html")

def beleza(request):
    return render(request,"beleza.html")

def alimentacao(request):
    return render(request,"alimentacao.html")