from django.apps import AppConfig


class Exer5Config(AppConfig):
    name = 'Exer5'
